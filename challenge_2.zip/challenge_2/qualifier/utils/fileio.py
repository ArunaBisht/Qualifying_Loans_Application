import csv


def load_csv(csvpath):
    with open(csvpath, "r") as csvfile:
        data = []
        csvreader = csv.reader(csvfile, delimiter=",")
        next(csvreader)
        for row in csvreader:
            data.append(row)
    return data


# Saves qualifying loans as a .csv file.
def save_csv(qualifying_loans):
    header = ["Lender", "Max Loan Amount", "Max LTV", "Max DTI", "Min Credit Score", "Interest Rate"]
    print("Now writing data")
    with open("qualifying_loans.csv", "w", newline = "") as f:
        csvwriter = csv.writer(f)
        
        csvwriter.writerow(header)

        for loan in qualifying_loans:
            csvwriter.writerow(loan)
    
    print(".csv file successfully written! \n")